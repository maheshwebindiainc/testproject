=== CF7 Field Validation ===
Contributors: Aiyaz, maheshpatel 
Tags: Contact Form 7, CF7, CF7 validation, form, forms, contactform7, contact form, error message submit, Contact Forms 7, Contact Form 7 + Messages, Contact Forms, contacted, contacts, Additional Message Settings, add custom error message with contact form 7, custom error message, custom error messages, validation messages, custom validation messages, change Contact Form 7 error messages, Error Messages, Validation, wpcf7_messages, wpcf7_validate_text, wpcf7_validate_email, wpcf7_save_contact_form
Donate link: http://resumedirectory.in
Requires at least: 4.3.1
Tested up to: 4.3.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin provides custom error messages for each fields in contact form7.

== Description ==

This plugin provides custom error messages for each fields in contact form7.

== Installation ==
1. Upload plugin to the /wp-content/plugins/ directory.
2. Activate the plugin through the \'Plugins\' menu in WordPress admin. 
3. Add messages in contact form7 message tab after creating any form.

== Frequently Asked Questions ==
1. Can I create custom validation for multiple form?
Ans. Yes, You can create custom validation messages for each form.

== Screenshots ==
1. Screenshot 'Screenshot-1.png' shows custom error messages in contact form. 
2. Screenshot 'Screenshot-2.png' shows How to set custom error messages for each fields in contact form message Tab.

== Changelog ==
1.0 first release.